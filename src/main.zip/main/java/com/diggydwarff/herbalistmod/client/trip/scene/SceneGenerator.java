package com.diggydwarff.herbalistmod.client.trip.scene;

import com.diggydwarff.herbalistmod.client.trip.TripContext;
import com.diggydwarff.herbalistmod.client.trip.TripState;
import com.diggydwarff.herbalistmod.client.trip.rng.SeedMixer;
import com.diggydwarff.herbalistmod.client.trip.rng.SeededRng;
import com.diggydwarff.herbalistmod.client.trip.primitive.*;

import java.util.*;

public final class SceneGenerator {

    public static GeneratedScene generate(TripState state, TripContext ctx, int sceneIndex) {
        long sceneSeed = SeedMixer.sceneSeed(state.baseSeed, sceneIndex);
        SeededRng rng = new SeededRng(sceneSeed);

        int duration = rng.nextInt(20 * 20, 70 * 20);
        int fade = rng.nextInt(2 * 20, 6 * 20);

        // Selection: 1 major + 0-2 minors
        List<PrimitiveInstance> picked = new ArrayList<>();
        EnumSet<Tags> usedTags = EnumSet.noneOf(Tags.class);

        PrimitiveSpec major = pickOne(rng, ctx, true, usedTags);
        if (major != null) {
            picked.add(makeInstance(rng, major));
            usedTags.add(major.tag);
        }

        int minors = rng.nextInt(0, 3);
        for (int i = 0; i < minors; i++) {
            PrimitiveSpec minor = pickOne(rng, ctx, false, usedTags);
            if (minor == null) break;
            picked.add(makeInstance(rng, minor));
            usedTags.add(minor.tag);
        }

        // If generator fails early, ensure at least something
        if (picked.isEmpty()) {
            PrimitiveSpec fallback = PrimitiveRegistry.specs().iterator().next();
            picked.add(makeInstance(rng, fallback));
        }

        return new GeneratedScene(state.ticks, duration, fade, picked);
    }

    private static PrimitiveInstance makeInstance(SeededRng rng, PrimitiveSpec spec) {
        Primitive p = PrimitiveRegistry.get(spec.id);
        PrimitiveInstance inst = new PrimitiveInstance(p, spec, rng.nextLong());

        // basic generic params; primitives can read these
        inst.set("strength", rng.nextFloat(0.25f, 1.0f));
        inst.set("speed", rng.nextFloat(0.2f, 1.2f));
        return inst;
    }

    private static PrimitiveSpec pickOne(SeededRng rng, TripContext ctx, boolean wantMajor, EnumSet<Tags> usedTags) {
        List<PrimitiveSpec> candidates = new ArrayList<>();
        for (PrimitiveSpec s : PrimitiveRegistry.specs()) {
            if (s.major != wantMajor) continue;
            if (usedTags.contains(s.tag)) continue;
            if (!Collections.disjoint(usedTags, s.conflicts)) continue;
            candidates.add(s);
        }
        if (candidates.isEmpty()) return null;

        // weighted
        float total = 0f;
        for (PrimitiveSpec c : candidates) total += Math.max(0.0001f, c.weight);

        float r = rng.nextFloat(0f, total);
        float acc = 0f;
        for (PrimitiveSpec c : candidates) {
            acc += Math.max(0.0001f, c.weight);
            if (r <= acc) return c;
        }
        return candidates.get(candidates.size() - 1);
    }
}