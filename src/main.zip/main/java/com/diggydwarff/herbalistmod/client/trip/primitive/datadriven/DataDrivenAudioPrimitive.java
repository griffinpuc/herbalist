package com.diggydwarff.herbalistmod.client.trip.primitive.datadriven;

import com.diggydwarff.herbalistmod.client.trip.TripContext;
import com.diggydwarff.herbalistmod.client.trip.TripState;
import com.diggydwarff.herbalistmod.client.trip.primitive.*;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;

public final class DataDrivenAudioPrimitive implements Primitive {
    private final PrimitiveDef def;

    public DataDrivenAudioPrimitive(PrimitiveDef def) { this.def = def; }

    @Override public String id() { return def.id; }
    @Override public Tags tag() { return def.tag; }

    @Override
    public void tick(TripState state, TripContext ctx, Minecraft mc, PrimitiveInstance inst) {
        if (mc.level == null || mc.player == null) return;

        float strength = clamp01(inst.get("strength", 0.6f)) * clamp01(state.intensity);
        if (strength < 0.2f) return;

        // deterministic-ish scheduling per instance
        int minD = Math.max(20, def.minDelayTicks);
        int maxD = Math.max(minD + 1, def.maxDelayTicks);
        int period = minD + (int)((maxD - minD) * 0.5f);

        // stagger by seed so multiple audio prims don't sync
        int offset = (int)(Math.abs(inst.seed) % period);
        if (((state.ticks + offset) % period) != 0) return;

        SoundEvent se = BuiltInRegistries.SOUND_EVENT.get(new ResourceLocation(def.sound));
        if (se == null) return;

        float vol = lerp(def.volMin, def.volMax, mc.level.random.nextFloat());
        float pitch = lerp(def.pitchMin, def.pitchMax, mc.level.random.nextFloat());

        double r = def.soundRadius <= 0 ? 60 : def.soundRadius;
        double x = mc.player.getX() + (mc.level.random.nextDouble() - 0.5) * r;
        double z = mc.player.getZ() + (mc.level.random.nextDouble() - 0.5) * r;
        double y = mc.player.getY() + 2.0 + mc.level.random.nextDouble() * 15.0;

        mc.level.playLocalSound(x, y, z, se, SoundSource.AMBIENT, vol, pitch, false);
    }

    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private static float clamp01(float v) { return v < 0 ? 0 : Math.min(v, 1); }
}