package com.diggydwarff.herbalistmod.client.trip.primitive.datadriven;

import com.diggydwarff.herbalistmod.client.trip.TripContext;
import com.diggydwarff.herbalistmod.client.trip.TripState;
import com.diggydwarff.herbalistmod.client.trip.primitive.*;
import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public final class DataDrivenParticlePrimitive implements Primitive {
    private final PrimitiveDef def;

    public DataDrivenParticlePrimitive(PrimitiveDef def) { this.def = def; }

    @Override public String id() { return def.id; }
    @Override public Tags tag() { return def.tag; }

    @Override
    public void tick(TripState state, TripContext ctx, Minecraft mc, PrimitiveInstance inst) {
        if (mc.level == null || mc.player == null) return;

        float strength = clamp01(inst.get("strength", 0.6f)) * clamp01(state.intensity);
        if (strength < 0.05f) return;

        Level level = mc.level;
        ParticleOptions p = resolveParticle(def.particle);

        int count = Mth.clamp((int)(lerp(def.minCount, def.maxCount, strength)), def.minCount, def.maxCount);
        float r = def.radius <= 0 ? 10f : def.radius;

        String pattern = def.pattern == null ? "cloud" : def.pattern;

        double px = mc.player.getX();
        double py = mc.player.getY();
        double pz = mc.player.getZ();

        switch (pattern) {
            case "ring" -> {
                double base = state.ticks * 0.05 * inst.get("speed", 0.6f);
                double rad = 2.5 + strength * 5.0;
                for (int i = 0; i < count; i++) {
                    double ang = base + (Math.PI * 2.0 * i / Math.max(1, count));
                    double x = px + Math.cos(ang) * rad;
                    double z = pz + Math.sin(ang) * rad;
                    double y = py + 1.0 + Math.sin(ang * 2.0) * 0.6;
                    level.addParticle(p, x, y, z, 0, 0.01, 0);
                }
            }
            case "horizon_blob" -> {
                Vec3 look = mc.player.getLookAngle().normalize();
                double dist = 90.0 + 80.0 * strength;
                double cx = px + look.x * dist;
                double cz = pz + look.z * dist;
                double cy = py + 10.0;
                for (int i = 0; i < count; i++) {
                    double ox = (level.random.nextDouble() - 0.5) * (20.0 + 30.0 * strength);
                    double oz = (level.random.nextDouble() - 0.5) * (20.0 + 30.0 * strength);
                    double oy = level.random.nextDouble() * (8.0 + 18.0 * strength);
                    level.addParticle(p, cx + ox, cy + oy, cz + oz, 0, 0.0, 0);
                }
            }
            case "upward_snow" -> {
                for (int i = 0; i < count; i++) {
                    double ox = (level.random.nextDouble() - 0.5) * r;
                    double oz = (level.random.nextDouble() - 0.5) * r;
                    double oy = def.yMin + level.random.nextDouble() * Math.max(0.1, (def.yMax - def.yMin));
                    double vx = (level.random.nextDouble() - 0.5) * 0.01;
                    double vy = 0.02 + level.random.nextDouble() * 0.03;
                    double vz = (level.random.nextDouble() - 0.5) * 0.01;
                    level.addParticle(p, px + ox, py + oy, pz + oz, vx, vy, vz);
                }
            }
            default -> { // "cloud"
                for (int i = 0; i < count; i++) {
                    double ox = (level.random.nextDouble() - 0.5) * r;
                    double oz = (level.random.nextDouble() - 0.5) * r;
                    double oy = def.yMin + level.random.nextDouble() * Math.max(0.1, (def.yMax - def.yMin));
                    double vx = (level.random.nextDouble() - 0.5) * 0.02;
                    double vy = -0.02 - level.random.nextDouble() * 0.03;
                    double vz = (level.random.nextDouble() - 0.5) * 0.02;
                    level.addParticle(p, px + ox, py + 2.0 + oy, pz + oz, vx, vy, vz);
                }
            }
        }
    }

    private static ParticleOptions resolveParticle(String id) {
        if (id == null || id.isBlank()) return ParticleTypes.ASH;

        try {
            ResourceLocation rl = ResourceLocation.tryParse(id);
            if (rl == null) return ParticleTypes.ASH;

            ParticleType<?> type = BuiltInRegistries.PARTICLE_TYPE.get(rl);
            if (type instanceof SimpleParticleType simple) {
                return simple;
            }
        } catch (Throwable ignored) {
        }
        // Non-simple particles (dust, block, item, vibration, etc.) need params.
        return ParticleTypes.ASH;
    }

    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private static float clamp01(float v) { return v < 0 ? 0 : Math.min(v, 1); }
}