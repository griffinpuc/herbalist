package com.diggydwarff.herbalistmod.client.trip;

import com.diggydwarff.herbalistmod.client.trip.primitive.Tags;

public final class TripProfiles {

    private TripProfiles() {}

    public static TripProfile introspectionI() {
        TripProfile p = new TripProfile("introspection_i");

        p.tagWeightMult.put(Tags.WORLD, 1.25f);
        p.tagWeightMult.put(Tags.POSTFX, 1.35f);
        p.tagWeightMult.put(Tags.ATMOSPHERE, 1.15f);
        p.tagWeightMult.put(Tags.AUDIO, 1.10f);

        p.primitiveWeightMult.put("postfx.mirage", 1.35f);
        p.primitiveWeightMult.put("atmo.context_tint", 1.25f);

        p.strengthMult = 1.10f;
        p.speedMult = 0.95f;

        return p;
    }

    public static TripProfile introspectionII() {
        TripProfile p = new TripProfile("introspection_ii");

        p.tagWeightMult.put(Tags.WORLD, 1.45f);
        p.tagWeightMult.put(Tags.POSTFX, 1.60f);
        p.tagWeightMult.put(Tags.CAMERA, 1.25f);
        p.tagWeightMult.put(Tags.ATMOSPHERE, 1.20f);

        p.primitiveWeightMult.put("postfx.mirage", 1.60f);
        p.primitiveWeightMult.put("fov.pulse", 1.25f);

        p.strengthMult = 1.20f;
        p.speedMult = 1.05f;

        return p;
    }
}