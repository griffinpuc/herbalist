package com.diggydwarff.herbalistmod.client.trip.primitive.datadriven;

import com.diggydwarff.herbalistmod.client.trip.TripContext;
import com.diggydwarff.herbalistmod.client.trip.TripState;
import com.diggydwarff.herbalistmod.client.trip.primitive.*;
import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;

public final class DataDrivenEntityParticlePrimitive implements Primitive {
    private final PrimitiveDef def;

    public DataDrivenEntityParticlePrimitive(PrimitiveDef def) { this.def = def; }

    @Override public String id() { return def.id; }
    @Override public Tags tag() { return def.tag; }

    @Override
    public void tick(TripState state, TripContext ctx, Minecraft mc, PrimitiveInstance inst) {
        if (mc.level == null || mc.player == null) return;

        float strength = clamp01(inst.get("strength", 0.6f)) * clamp01(state.intensity);
        if (strength < 0.15f) return;

        String mode = def.entityPattern == null ? "ring" : def.entityPattern;
        ParticleOptions p = resolveParticle(def.particle);

        int max = Math.max(1, def.entityMax);
        float rad = def.entityRadius <= 0 ? 1.2f : def.entityRadius;

        int used = 0;
        double base = state.ticks * 0.08 * inst.get("speed", 0.6f);

        for (Entity e : mc.level.entitiesForRendering()) {
            if (e == mc.player) continue;
            if (e.distanceToSqr(mc.player) > 18 * 18) continue;

            if (mode.equals("trail")) {
                mc.level.addParticle(p, e.getX(), e.getY() + 0.9, e.getZ(), 0, 0.01, 0);
            } else {
                int points = 4 + (strength > 0.65f ? 4 : 0); // denser ring at higher strength
                for (int i = 0; i < points; i++) {
                    double ang = base + (Math.PI * 2.0 * i / (double) points);
                    double x = e.getX() + Math.cos(ang) * rad;
                    double z = e.getZ() + Math.sin(ang) * rad;
                    double y = e.getY() + 0.9;
                    mc.level.addParticle(p, x, y, z, 0, 0.01, 0);
                }
            }

            used++;
            if (used >= max) break;
        }
    }

    private static ParticleOptions resolveParticle(String id) {
        if (id == null || id.isBlank()) return ParticleTypes.END_ROD;

        try {
            ResourceLocation rl = ResourceLocation.tryParse(id);
            if (rl == null) return ParticleTypes.END_ROD;

            ParticleType<?> type = BuiltInRegistries.PARTICLE_TYPE.get(rl);
            if (type instanceof SimpleParticleType simple) {
                return simple;
            }
        } catch (Throwable ignored) {
        }
        return ParticleTypes.END_ROD;
    }

    private static float clamp01(float v) { return v < 0 ? 0 : Math.min(v, 1); }
}