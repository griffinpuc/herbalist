package com.diggydwarff.herbalistmod.client.trip;

import com.diggydwarff.herbalistmod.client.trip.primitive.PrimitiveRegistry;
import com.diggydwarff.herbalistmod.client.trip.scene.GeneratedScene;
import com.diggydwarff.herbalistmod.client.trip.scene.SceneGenerator;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.ViewportEvent;

import java.util.List;

public final class TripDirector {
    private static final TripDirector INSTANCE = new TripDirector();
    public static TripDirector get() { return INSTANCE; }

    private final TripState state = new TripState();
    private final TripContextSampler contextSampler = new TripContextSampler();

    private GeneratedScene current;
    private int sceneIndex = 0;

    private boolean debugCycleEnabled = false;
    private int debugIndex = 0;
    private int debugPeriodTicks = 5 * 20;
    private int debugNextSwitchTick = 0;
    private String debugForcedPrimitiveId = null;

    private TripDirector() {
        PrimitiveRegistry.bootstrap();
    }

    public void tick(Minecraft mc) {
        state.tick(mc);

        if (!state.active) {
            current = null;
            return;
        }

        TripContext ctx = contextSampler.sample(mc);

        if (current == null || current.isFinished()) {
            current = SceneGenerator.generate(state, ctx, sceneIndex++);
        }

        current.tick(ctx, state);
    }

    public void debugStartCycle(int seconds) {
        debugCycleEnabled = true;
        debugPeriodTicks = Math.max(1, seconds) * 20;
        debugNextSwitchTick = state.ticks; // switch immediately on next tick
        debugForcedPrimitiveId = null;
        current = null;
    }

    public void debugStopCycle() {
        debugCycleEnabled = false;
        debugForcedPrimitiveId = null;
        current = null;
    }

    public void debugNext() {
        debugCycleEnabled = true;
        debugNextSwitchTick = state.ticks; // force immediate switch
        debugForcedPrimitiveId = null;
        current = null;
    }

    public void debugSet(String id) {
        debugCycleEnabled = false;
        debugForcedPrimitiveId = id;
        current = null;
    }

    public List<String> debugListIds() {
        return PrimitiveRegistry.specs().stream().map(s -> s.id).sorted().toList();
    }

    public void onFogColor(ViewportEvent.ComputeFogColor event) {
        if (current == null || !state.active) return;
        current.onFogColor(state, event);
    }

    public void onFov(ViewportEvent.ComputeFov event) {
        if (current == null || !state.active) return;
        current.onFov(state, event);
    }

    public void onRenderStage(RenderLevelStageEvent event) {
        if (current == null || !state.active) return;
        current.onRenderStage(state, event);
    }
}