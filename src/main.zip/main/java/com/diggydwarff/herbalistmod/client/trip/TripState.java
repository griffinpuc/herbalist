package com.diggydwarff.herbalistmod.client.trip;

import net.minecraft.client.Minecraft;

import com.diggydwarff.herbalistmod.client.trip.rng.SeedMixer;

import java.util.ArrayDeque;
import java.util.Deque;

public final class TripState {

    public boolean active = false;
    public int ticks = 0;

    public long tripSessionId = 0L;
    public long baseSeed = 0L;

    public float intensity = 0f; // 0..1

    public TripProfile profile = new TripProfile("default");

    private final Deque<String> recentPrimitiveIds = new ArrayDeque<>();

    // ---------------------------------------------------------
    // Lifecycle
    // ---------------------------------------------------------

    public void startTrip(Minecraft mc, long seed, TripProfile profile) {
        this.active = true;
        this.ticks = 0;
        this.tripSessionId = System.nanoTime();

        this.profile = (profile != null) ? profile : new TripProfile("default");

        long a = mc.player != null ? mc.player.getUUID().getLeastSignificantBits() : 1234L;
        long b = mc.player != null ? mc.player.getUUID().getMostSignificantBits() : 5678L;

        // Mix seed with player UUID + session id
        this.baseSeed = SeedMixer.mix64(
                seed
                        ^ SeedMixer.mix64(a)
                        ^ SeedMixer.mix64(b ^ tripSessionId)
        );

        recentPrimitiveIds.clear();
    }

    public void stopTrip() {
        this.active = false;
        this.ticks = 0;
        this.intensity = 0f;
        recentPrimitiveIds.clear();
    }

    // ---------------------------------------------------------
    // Tick
    // ---------------------------------------------------------

    public boolean seenRecently(String id) {
        return recentlyUsed(id);
    }

    public void tick(Minecraft mc) {
        if (!active) return;

        ticks++;

        // 60 second intensity triangle wave
        int cycle = 20 * 60;
        int t = ticks % cycle;
        float x = t / (float) cycle;

        float tri = x < 0.5f ? (x * 2f) : (2f - x * 2f);
        intensity = clamp01(tri);
    }

    // ---------------------------------------------------------
    // Primitive history
    // ---------------------------------------------------------

    public void notePrimitive(String id) {
        if (id == null) return;
        recentPrimitiveIds.addLast(id);
        if (recentPrimitiveIds.size() > 6) {
            recentPrimitiveIds.removeFirst();
        }
    }

    public boolean recentlyUsed(String id) {
        return recentPrimitiveIds.contains(id);
    }

    // ---------------------------------------------------------
    // Utils
    // ---------------------------------------------------------

    private static float clamp01(float v) {
        return Math.max(0f, Math.min(1f, v));
    }
}