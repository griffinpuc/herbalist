package com.diggydwarff.herbalistmod.client.handler;

import com.diggydwarff.herbalistmod.HerbalistMod;
import com.diggydwarff.herbalistmod.client.trip.TripDirector;
import com.diggydwarff.herbalistmod.client.trip.primitive.PrimitiveRegistry;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = HerbalistMod.MODID, value = Dist.CLIENT)
public final class TripClientEvents {

    private static boolean primBoot = false;

    private static boolean bootstrapped = false;
    private static boolean ddLoaded = false;

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getInstance();

        if (!ddLoaded && mc.level != null) {
            ddLoaded = true;
            System.out.println("[Trip] FORCING datadriven load now");
            com.diggydwarff.herbalistmod.client.trip.primitive.datadriven.DataDrivenPrimitiveLoader.loadAllIntoRegistry();
            System.out.println("[Trip] After load, primitive count = " + com.diggydwarff.herbalistmod.client.trip.primitive.PrimitiveRegistry.specs().size());
        }

        TripDirector.get().tick(mc);
    }

    @SubscribeEvent
    public static void onFogColor(ViewportEvent.ComputeFogColor event) {
        TripDirector.get().onFogColor(event);
    }

    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov event) {
        TripDirector.get().onFov(event);
    }

    @SubscribeEvent
    public static void onRenderLevelStage(RenderLevelStageEvent event) {
        TripDirector.get().onRenderStage(event);
    }
}