package com.diggydwarff.herbalistmod.client.trip.primitive.world;

import com.diggydwarff.herbalistmod.client.trip.*;
import com.diggydwarff.herbalistmod.client.trip.primitive.*;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;

public final class HorizonSilhouettePrimitive implements Primitive {

    @Override public String id() { return "world.horizon_silhouette"; }
    @Override public Tags tag() { return Tags.WORLD; }

    @Override
    public void onRenderStage(TripState state, RenderLevelStageEvent e, PrimitiveInstance inst) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_SKY) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        float strength = inst.get("strength", 0.7f) * state.intensity;
        if (strength < 0.05f) return;

        PoseStack pose = e.getPoseStack();
        Matrix4f matrix = pose.last().pose();

        Tesselator t = Tesselator.getInstance();
        BufferBuilder buf = t.getBuilder();

        double distance = 120;
        double width = 60 + strength * 40;
        double height = 20 + strength * 30;

        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        buf.vertex(matrix, (float)-width, 10f, (float)-distance).color(0.1f, 0.0f, 0.2f, 0.7f).endVertex();
        buf.vertex(matrix, (float) width, 10f, (float)-distance).color(0.1f, 0.0f, 0.2f, 0.7f).endVertex();
        buf.vertex(matrix, (float) width, (float)(10 + height), (float)-distance).color(0.2f, 0.0f, 0.4f, 0.7f).endVertex();
        buf.vertex(matrix, (float)-width, (float)(10 + height), (float)-distance).color(0.2f, 0.0f, 0.4f, 0.7f).endVertex();
        t.end();
    }
}